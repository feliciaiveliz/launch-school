# Chapter 5 Quiz: Answers

1. **C**
2. **B** 
3. **A**
4. **B, D**
5. **D**

---

- **What is the purpose of `typedef`?**

    A. It allows you to pass a struct to a function

    B. It allows you to change or update the data fields of a struct

    C. It allows you to create an alias for a struct that you define

    D. It combines exisiting data types and creates a new data type

- **Which line of code would produce the expected output for this code?**

    ```c
    typedef struct { 
      const char *food;
      const char *personality;
    } animal;

    typedef struct {
      const char *name;
      animal info;
    } bird;

    int main()
    {
      bird winter = {"Winter", {"mice", "solitary"}};
      printf("Name: %s\nFood: %s\nPersonality: %s\n", <line of code goes here>);
    }
    ```

    A. winter.info.name, winter.food, winter.personality

    B. winter.name, winter.info.food, winter.info.personality

    C. winter.info.food, winter.info.personality, winter.name

    D. winter.name, winter.food, winter.personality

    ---

- **Which line of code would need to be added to this code to match the output? Select all that apply.**

    ```c
    typedef struct {
     const char *name;
     const char *type;
    } bird; ;

    int main()
    {
     <line of code goes here>
     printf("Name: %s\nType: %s\n", winter.name, winter.type);
     return 0;
    }
    ```

    A. `bird winter = {"Winter", "Snowy Owl"};`

    B. `Bird winter = {"Snowy Owl", “Winter”};`

    C. `bird winter = {"Winter", "Snowy Owl"}`

    D. `bird = {"Winter", "Snowy Owl"};`

- **What is another way to write this code? Select all that apply.**

    ```c
    struct bird {
      ...
    }
    ```

    A.

    ```c
    struct bird {
      ...
    } bird;
    ```

    B.

    ```c
    typedef struct bird {
      ...
    } bird;
    ```

    C.

    ```c
    struct bird {
      ...
    } typedef bird;
    ```

    D.

    ```c
    typedef struct {
      ...
    } bird;
    ```

- **What needs to happen in order to allow a function to update or change a struct's data fields?**

    A. You need to pass a copy of the struct to the function

    B. You need to pass the the individual values for the data fields to the function

    C. You need to pass an array containing the data fields to the function

    D. You need to pass a pointer to the function